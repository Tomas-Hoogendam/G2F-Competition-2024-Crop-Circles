#!/usr/bin/env python3
# merge_csvs.py : Python script for merging input data in .csv-format.
# Written for GxE Maize contest 2024.
# Usage: clean_proc_merge_csvs.py -h
# Authors: Job J. Dirkmaat, Tomas Hoogendam & Shivam Sharma

# imports required

import argparse
import pandas as pd
import numpy as np
import json
import pathlib
from joblib import Parallel, delayed
from sklearn.feature_selection import SelectKBest, f_classif
import sys

# definitions
def is_csv_file(file_path):
    """ Simple check to verify input files are .csv format."""
    try:
        pd.read_csv(file_path, nrows=1)  # only check first row
    except Exception as e:
        raise argparse.ArgumentTypeError(f"Invalid CSV file: {e}")
    return file_path


def validate_threshold(value):
    """ Simple check to verify given threshold is float between 0 and 1."""
    value = float(value)
    if not 0 <= value <= 1:
        raise argparse.ArgumentTypeError("Threshold value must be between 0 and 1.")
    return value


def validate_columns(columns_drop, files_csv):
    """ Simple check to verify that columns that are given to drop from the data are
     actually in the data to begin with."""
    # read columns to drop
    with open(columns_drop, 'r') as file:
        columns_to_drop = [line.strip() for line in file]

    # get column names of all csv files
    all_headers = set()
    for csv_file in files_csv:
        df = pd.read_csv(csv_file, nrows=0)
        all_headers.update(df.columns)

    # check that all columns to drop exist
    missing_columns = [col for col in columns_to_drop if col not in all_headers]
    if missing_columns:
        raise ValueError(f"The following columns are do not exist: {missing_columns}")

    return columns_to_drop


def parse_arguments():
    """ Provide CL interface to script. """
    descrip = """
    Python3 script for CL use. Clean up, processes and merges input .csv-format data and processes to one .csv 
    file for use in random forest regression.
        """

    epilog = """
    Wisdom of the day:
    You find true joy and happiness in life when you give and give and go on giving and never count the cost.
    - Eileen Caddy
    """

    parser = argparse.ArgumentParser(prog="clean_proc_merge_csvs.py", description=descrip, epilog=epilog)

    # add arguments
    parser.add_argument("-c", "--csvs", help="path to .csv files to merge without processing",
                        required=True, nargs='+', type=is_csv_file)

    parser.add_argument("-w", "--weathercsv", help="path to .csv file with data on full year",
                        required=True, nargs=1, type=is_csv_file)

    parser.add_argument("-v", "--vcf", help="path to .vcf file with genotype data",
                        required=True, nargs=1, type=is_csv_file)

    parser.add_argument("-n", "--colname", help="name of column to merge files on",
                        required=True, type=str)

    parser.add_argument("-t", "--threshold", help="threshold for completeness of column as percentage filled",
                        required=True, nargs=1, type=validate_threshold)

    parser.add_argument("-d", "--coldrop", help="file of list of columns to drop as one column name per newline",
                        required=True, nargs=1, type=str)

    parser.add_argument("-o1", "--outcsv", help="path and name of output .csv file",
                        required=False, type=pathlib.Path, default="./GxE_merged_data_2.csv")

    parser.add_argument("-o2", "--outtype", help="path and name of output data types file",
                        required=False, type=pathlib.Path, default="./GxE_merged_data_types_pred.json")

    args = parser.parse_args()

    return args


def one_hot_encode_column(merged_df, col):
    """ One-hot encode a single given column. """
    return pd.get_dummies(merged_df[col], prefix=col)


# def: merge csv files
def merge_csv_files(csvs, df_geno, columns_to_drop, thres_comp, merged_csv, types_file, common_column):
    """ Processes, merges, and cleans up input data to single .csv for
    subsequent analysis by random_forest.py. """

    # Read and merge CSV files
    merged_df = None

    # check if dataframe or csv
    for file_or_df in csvs:
        if isinstance(file_or_df, pd.DataFrame):
            df = file_or_df
        else:
            df = pd.read_csv(file_or_df)

        # check if common column exists
        if common_column not in df.columns:
            print(f"Column '{common_column}' not found in file: {file_or_df}")
            continue

        # merge data
        if merged_df is None:
            merged_df = df
        else:
            merged_df = pd.merge(merged_df, df, on=common_column, how='outer')

    # check if merging successful
    if merged_df is None or merged_df.empty:
        print("No files were merged due to missing common column.")
        return

    # add genotype based on different common column
    merged_df = pd.merge(merged_df, df_geno, on="Hybrid", how='outer')

    # clean up dataset
    # drop columns by header
    merged_df = merged_df.drop(columns=columns_to_drop)

    # drop rows without yield
    merged_df = merged_df.dropna(subset=['Yield_Mg_ha'])

    # Identify and store columns passing the threshold
    na_cols = merged_df.columns[(merged_df.notna().mean() < thres_comp) & (merged_df.isna().any())].tolist()

    # remove columns of less than threshold completeness
    merged_df = merged_df.loc[:, merged_df.notna().mean() >= thres_comp]

    # dictionary to store inferred datatypes
    column_types = {}

    # fill or remove leftover NaN values based on data type
    for col in merged_df.columns:
        # infer datatype of column
        current_type = merged_df[col].to_numpy().dtype

        if col in column_types:
            # find compatible type
            column_types[col] = np.result_type(column_types[col], current_type)
        else:
            column_types[col] = current_type

        # replace NAs based on datatype
        if col in na_cols:
            if np.issubdtype(column_types[col], np.number):
                merged_df[col] = merged_df[col].fillna(merged_df[col].median())
            else:
                merged_df[col] = merged_df[col].fillna('Unknown')
        else:
            continue

    # convert np.dtype to string for json storing
    column_types = {col: str(dtype) for col, dtype in column_types.items()}

    # save inferred column data types for later use
    with open(types_file, "w") as file:
        json.dump(column_types, file)
    print(f"Column types saved to {types_file}")

    # convert merged dataframe columns using one-hot encoding
    print("Started one-hot encoding for non-numerical columns")
    object_cols = [col for col, dtype in column_types.items() if dtype == "object"]

    # parallelize one-hot encoding for object columns
    encoded_cols = Parallel(n_jobs=14)(
        delayed(one_hot_encode_column)(merged_df, col) for col in object_cols
    )

    # change original columns to encoded columns
    merged_df = pd.concat([merged_df.drop(columns=object_cols)] + encoded_cols, axis=1)

    # Save the merged DataFrame to a CSV file
    merged_df.to_csv(merged_csv, index=False)
    print(f"Merged CSV saved to {merged_csv}")


def weather_proc(weather_csv):
    """ Processing of weather data .csv file."""
    # Load the data
    df = pd.read_csv(weather_csv)

    # Convert the 'Date' column to datetime format
    df['Date'] = pd.to_datetime(df['Date'], format='%Y%m%d')

    # Extract the week number and year for each date
    df['Week'] = df['Date'].dt.isocalendar().week
    df['Year'] = df['Date'].dt.year

    # Drop Week 53 if present
#    df = df[df['Week'] <= 52]

    # List of relevant columns to calculate statistics for
    columns_to_process = [
        'RH2M', 'T2M_MAX', 'ALLSKY_SFC_SW_DWN', 'T2MWET', 'GWETTOP', 'QV2M', 
        'GWETPROF', 'T2M_MIN', 'T2MDEW', 'PS', 'T2M', 'GWETROOT',
        'ALLSKY_SFC_PAR_TOT', 'WS2M', 'ALLSKY_SFC_SW_DNI', 'PRECTOTCORR'
    ]

    # Initialize the final dataframe as a list to collect rows
    final_rows = []

    # Process each environment individually
    for env, env_data in df.groupby('Env'):
        env_result = {'Env': env}

        # Loop over each column to calculate weekly and rolling averages
        for col in columns_to_process:
            weekly_stats = []
            rolling_stats = []

            # Extract weekly data
            for week in range(1, 45):
                week_data = env_data[env_data['Week'] == week][col]
                if not week_data.empty:
                    weekly_stats.append({
                        'min': week_data.min(),
                        'max': week_data.max(),
                        'mean': week_data.mean()
                    })
                else:
                    weekly_stats.append({'min': np.nan, 'max': np.nan, 'mean': np.nan})

            # Calculate 2-week rolling averages
            for i in range(len(weekly_stats)):
                if i == 0:
                    rolling_stats.append(weekly_stats[i])  # Week 1 rolling stats = Week 1 stats
                else:
                    rolling_min = np.nanmean([weekly_stats[max(0, i-1)]['min'], weekly_stats[i]['min']])
                    rolling_max = np.nanmean([weekly_stats[max(0, i-1)]['max'], weekly_stats[i]['max']])
                    rolling_mean = np.nanmean([weekly_stats[max(0, i-1)]['mean'], weekly_stats[i]['mean']])
                    rolling_stats.append({'min': rolling_min, 'max': rolling_max, 'mean': rolling_mean})

            # Add weekly averages to the result
            for week, stats in enumerate(weekly_stats, start=1):
                env_result[f"Avg {col} Min Week {week}"] = stats['min']
                env_result[f"Avg {col} Max Week {week}"] = stats['max']
                env_result[f"Avg {col} Mean Week {week}"] = stats['mean']

            # Add rolling averages to the result
            for week, stats in enumerate(rolling_stats, start=1):
                env_result[f"Rolling Avg {col} Min Week {week}"] = stats['min']
                env_result[f"Rolling Avg {col} Max Week {week}"] = stats['max']
                env_result[f"Rolling Avg {col} Mean Week {week}"] = stats['mean']

        # Collect the environment results into the final rows list
        final_rows.append(env_result)

    # Convert the list of rows to a DataFrame
    hybrid_data = pd.DataFrame(final_rows)

    return hybrid_data


#Genetic data Pre-processing

# File paths
vcf_file = "Path_to_file/5_Genotype_Data_All_2014_2025_Hybrids.vcf" 
trait_file = "Path_to_file/1_Training_Trait_Data_2014_2023.csv"  

# Load trait data
trait_df = pd.read_csv(trait_file)

# Validate columns in the trait file
if 'Hybrid' not in trait_df.columns or 'Yield_Mg_ha' not in trait_df.columns:
    raise ValueError("The trait file must contain 'Hybrid' and 'Yield_Mg_ha' columns.")

# Load VCF file and extract genotype columns
try:
    with open(vcf_file, "r") as f:
        column_names = []
        vcf_data = []

        for line in f:
            if line.startswith("#CHROM"):
                # Extract column names from the header
                column_names = line.strip().split("\t")
            elif not line.startswith("#"):
                # Append data rows
                vcf_data.append(line.strip().split("\t"))

        if not column_names:
            raise ValueError("Header row starting with #CHROM was not found. Check the VCF file.")

    # Convert to a DataFrame
    vcf_df = pd.DataFrame(vcf_data, columns=column_names)

    print("\nVCF file loaded successfully. Sample data:")
    print(vcf_df.head())

except Exception as e:
    print(f"Error loading VCF file: {e}")
    vcf_df = None

# Extract SNP data (columns with genotypes) and meta-information
snp_data_raw = vcf_df.iloc[:, 9:]  # Genotypes start at the 10th column
snp_metadata = vcf_df.iloc[:, :9]  # SNP metadata

def encode_genotype(genotype_str):
    """Encodes genotypes as numerical values."""
    if genotype_str == '0/0':
        return 0
    elif genotype_str == '0/1' or genotype_str == '1/0':
        return 1
    elif genotype_str == '1/1':
        return 2
    else:
        return np.nan


def analyze_vcf(vcf_file, trait_file):
    """ Analyze genotypic data from a .vcf format file."""
    # Load trait data
    trait_df = pd.read_csv(trait_file)

    # Validate columns in the trait file
    if 'Hybrid' not in trait_df.columns or 'Yield_Mg_ha' not in trait_df.columns:
        raise ValueError("The trait file must contain 'Hybrid' and 'Yield_Mg_ha' columns.")

    # Load VCF file and extract genotype columns
    try:
        with open(vcf_file, "r") as f:
            column_names = []
            vcf_data = []

            for line in f:
                if line.startswith("#CHROM"):
                    # Extract column names from the header
                    column_names = line.strip().split("\t")
                elif not line.startswith("#"):
                    # Append data rows
                    vcf_data.append(line.strip().split("\t"))

            if not column_names:
                raise ValueError("Header row starting with #CHROM was not found. Check the VCF file.")

        # Convert to a DataFrame
        vcf_df = pd.DataFrame(vcf_data, columns=column_names)

        # print("\nVCF file loaded successfully. Sample data:")
        # print(vcf_df.head())

    except Exception as e:
        print(f"Error loading VCF file: {e}")
        vcf_df = None

    # Extract SNP data (columns with genotypes) and meta-information
    snp_data_raw = vcf_df.iloc[:, 9:]  # Genotypes start at the 10th column
    snp_metadata = vcf_df.iloc[:, :9]  # SNP metadata

    # Calculate mean and variance for Yield_Mg_ha
    trait_df = trait_df[trait_df['Yield_Mg_ha'].notna()]
    trait_stats = trait_df.groupby('Hybrid')['Yield_Mg_ha'].agg(['mean', 'var']).reset_index()
    trait_stats.rename(columns={'mean': 'Yield_mean', 'var': 'Yield_variance'}, inplace=True)

    # Ensure that all genotypes in the trait file are present in the VCF file
    genotypes_in_vcf = snp_data_raw.columns.tolist()

    # Filter trait file to only include genotypes also present in the VCF
    trait_stats = trait_stats[trait_stats['Hybrid'].isin(genotypes_in_vcf)]

    # Filter SNP data to only include genotypes present in the filtered trait file

    # Apply encoding
    snp_data_encoded = snp_data_raw.apply(lambda col: col.map(encode_genotype))

    # Handle missing values by filling with the mode (most frequent value) for each SNP
    snp_data_encoded.fillna(snp_data_encoded.mode().iloc[0], inplace=True)

    # Merge SNP data with the trait statistics
    trait_target = trait_stats.set_index('Hybrid')
    snp_data_encoded = snp_data_encoded.T
    snp_data_encoded['Hybrid'] = snp_data_encoded.index

    merged_data = snp_data_encoded.merge(trait_target, left_on='Hybrid', right_index=True)

    # Extract target values and SNP data
    y = merged_data['Yield_mean'].values  # Use mean as the target
    x = merged_data.drop(columns=['Hybrid', 'Yield_mean', 'Yield_variance'])

    # Feature selection: Select top k SNPs
    k = min(400, x.shape[1])  # Adjust k as needed
    selector = SelectKBest(score_func=f_classif, k=k)
    selector.fit(x, y)

    selected_features = selector.get_support(indices=True)
    selected_snp_ids = snp_metadata.iloc[selected_features, 2]  # Use SNP IDs from metadata
    selected_snp_data = x.iloc[:, selected_features]


    # Transpose SNP data back to original format (genotypes as rows)
    selected_snp_data['Hybrid'] = merged_data['Hybrid']
    final_df = selected_snp_data.set_index('Hybrid')

    # Add SNP IDs as column names
    final_df.columns = selected_snp_ids.values
    print("Genetic pre-processing complete")

    return final_df

# main code
if __name__ == "__main__":
    # retrieve CL arguments
    arguments = parse_arguments()

    csv_files = arguments.csvs
    weather_data = arguments.weathercsv[0]
    geno_vcf = arguments.vcf[0]
    com_col = arguments.colname
    threshold = arguments.threshold[0]
    col_drop = arguments.coldrop[0]
    outfile = arguments.outcsv
    outtype = arguments.outtype

    # verify columns to drop exist
    drop_col = validate_columns(col_drop, csv_files)

    # retrieve path to trait info file from csvs
    trait_files = [file for file in csv_files if "trait" in file.lower()]

    # verify file
    if len(trait_files) == 1:
        trait_path = trait_files[0]
    elif len(trait_files) > 1:
        print(f"Found {num_file} files containing 'trait': {trait_files}.")
        sys.exit()
    else:
        print("No file was found matching 'trait' data.")
        sys.exit()

    # analyze weather data (training)
    weather_df = weather_proc(weather_data)

    # add weather dataframe to csv files to merge
    csv_files.append(weather_df)

    # analyze and process genotype data (training)
    
    geno_df = analyze_vcf(geno_vcf, trait_path)

    # merge csv files
    merge_csv_files(csv_files, geno_df, drop_col, threshold, outfile, outtype, com_col)