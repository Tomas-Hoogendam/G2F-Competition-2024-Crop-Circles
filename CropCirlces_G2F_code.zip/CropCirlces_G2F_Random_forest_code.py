#!/usr/bin/env python3
# merge_csvs.py : Python script for merging input data in .csv-format.
# Written for GxE Maize contest 2024.
# Usage: clean_proc_merge_csvs.py -h
# Authors: Job J. Dirkmaat & Tomas Hoogendam

# imports required
import argparse
import pathlib
import numpy as np
import pandas as pd
import json
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score
import time
import sys


# definitions
# def: format check
def is_csv_file(file_path):
    try:
        pd.read_csv(file_path, nrows=1)  # only check first row
    except Exception as e:
        raise argparse.ArgumentTypeError(f"Invalid CSV file: {e}")
    return file_path


# def: provide CL interface to script
def parse_arguments():
    descrip = """
    Python3 script for CL use. Run Random Forest Regression on .csv file and evaluates model performance
        """

    epilog = """
    Wisdom of the day:
    The measure of mental health is the disposition to find good everywhere.
    - Ralph Waldo Emerson
    """

    parser = argparse.ArgumentParser(prog="random_forest.py", description=descrip, epilog=epilog)

    # add arguments
    parser.add_argument("-c", "--csv", help="path to .csv file",
                        required=True, nargs=1, type=is_csv_file)

    parser.add_argument("-t", "--types", help="path to column data types file",
                        required=True, nargs=1)

    parser.add_argument("-n", "--nest", help="number of decision trees in the forest",
                        required=True, nargs=1, type=int)

    parser.add_argument("-s", "--rseed", help="seed for random number generator",
                        required=False, nargs=1, type=int, default=42)

    parser.add_argument("-p", "--resp", help="column name of response variable",
                        required=True, nargs=1)

    parser.add_argument("-o", "--outfile", help="path and name of output file",
                        required=False, type=pathlib.Path, default="./random_forest_model")

    args = parser.parse_args()

    return args


# def: model training and evaluation
def train_eval(x_training, y_training, x_testing, y_testing):
    # train the full model
    print("\n Initializing and Training the RandomForestRegressor Model")
    start_full_training_time = time.time()
    model = RandomForestRegressor(n_estimators=num_trees, random_state=ran_seed, n_jobs=14)
    model.fit(x_training, y_training)
    full_training_time = time.time() - start_full_training_time
    print(f"Model training completed in {full_training_time:.2f} seconds.")

    # Evaluate the Model
    print("\n Evaluating the Model on Test Data")
    y_pred = model.predict(x_testing)
    mse = mean_squared_error(y_testing, y_pred)
    r2 = r2_score(y_testing, y_pred)

    # print completion statement
    print(f"Random forest regression of {csv_file} is completed and results are saved to {outfile}.")
    print(f"Mean Squared Error (MSE): {mse:.2f}")
    print(f"R-squared (R2): {r2:.2f}")

    return model


# main code
if __name__ == "__main__":
    # retrieve CL arguments
    arguments = parse_arguments()

    csv_file = arguments.csv[0]
    type_file = arguments.types[0]
    num_trees = arguments.nest[0]
    ran_seed = arguments.rseed[0]
    res_name = arguments.resp[0]
    outfile = arguments.outfile

    # load in data
    print("Loading data...")

    with open(type_file, "r") as file:
        types_json = json.load(file)

    # convert string types back to np.dtype
    column_types = {col: np.dtype(dtype) for col, dtype in types_json.items()}

    # extract datetime columns
    date_col = [col for col, dtype in column_types.items() if dtype == np.dtype('datetime64[ns]')]

    # remove datetime columns from types
    column_types_no_dt = {col: dtype for col, dtype in column_types.items() if dtype != np.dtype('datetime64[ns]')}

    # load in data
    df = pd.read_csv(csv_file, dtype=column_types_no_dt, parse_dates=date_col)  # .csv dataset

    # drop datetime columns
    df = df.drop(columns=date_col)

    # select predictors (independent) and response (dependent) values
    if res_name not in df.columns:
        raise ValueError(f"The response variable {res_name} is not found in the csv file")

    val_pred = df.drop(columns=[res_name])  # Replace 'target' with your target column name
    val_res = df[res_name]

    # split data into training and testing sets
    x_train, x_test, y_train, y_test = train_test_split(val_pred, val_res, test_size=0.15, random_state=ran_seed)

    print("Data successfully split into training and testing sets.")

    # run model training and evaluation
    rf_model = train_eval(x_train, y_train, x_test, y_test)
